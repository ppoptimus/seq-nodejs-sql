const sqlConfig = {
	user: "sa",
	password: "Peisui@2433",
	server: "localhost",
	database: "seq",
	options: {
		encrypt: false,
		charset: "utf8",
	},
}

module.exports = sqlConfig
